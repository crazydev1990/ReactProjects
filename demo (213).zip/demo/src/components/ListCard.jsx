import React from 'react'
import { useEffect, useState } from 'react'
import Card from './Card'
const ListCard = () => {

    const [productvalue, setProducts] = useState([])
    const products = async () => {
        const res = await fetch("https://dummyjson.com/products")
        const data = await res.json()
        // console.log(data.products);
        setProducts(data.products)
    }
    useEffect(() => {
        products()
    }, [])

    return (
        <div className='flex flex-wrap justify-center gap-2'>
            {productvalue.map((ele) => {
                // returnret ele.title
                // console.log(ele.title);
                return < Card key={ele.id} data={ele} />
            })}

        </div>
    )
}

export default ListCard