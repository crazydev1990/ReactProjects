// import React from 'react'

// const Moredetail = () => {
//     const count = JSON.parse(localStorage.getItem("cart"))
//     console.log(count);
//     return (
//         <>
//             <div className="container">
//                 {count.map((elel) => {
//                     console.log(elel);
//                     return (
//                         <div className="row justify-center align-items-center">
//                             <div className="col">
//                                 <img src={elel.thumbnail} alt="" />
//                             </div>
//                             <div className="col">
//                                 <h2>{elel.title}</h2>
//                                 <p>{elel.description}</p>
//                                 <p>{elel.price}</p>
//                                 <input type="number" name="" id="" value={elel.quantity} />
//                                 <p>{elel.stock}</p>

//                             </div>
//                         </div>

//                     )
//                 })}
//             </div>
//         </>
//     )
// }

// export default Moredetail



// import React, { useState } from 'react'

// const Moredetail = () => {
//     const [count, setCount] = useState(() => {
//         return JSON.parse(localStorage.getItem("cart")) || []
//     })

//     function increment(index) {
//         const updatedCart = [...count]

//         if (updatedCart[index].quantity < updatedCart[index].stock) {
//             updatedCart[index].quantity += 1
//         }

//         setCount(updatedCart)
//         localStorage.setItem("cart", JSON.stringify(updatedCart))
//     }

//     function decrement(index) {
//         const updatedCart = [...count]

//         if (updatedCart[index].quantity > 1) {
//             updatedCart[index].quantity -= 1
//         }

//         setCount(updatedCart)
//         localStorage.setItem("cart", JSON.stringify(updatedCart))
//     }

//     return (
//         <div className="container">
//             {count.map((elel, index) => (
//                 <div
//                     className="row align-items-center justify-content-center mb-4"
//                     key={elel.id || index}
//                 >
//                     <div className="col-md-5">
//                         <img
//                             src={elel.thumbnail}
//                             alt={elel.title}
//                             className="img-fluid"
//                         />
//                     </div>

//                     <div className="col-md-7">
//                         <h2>{elel.title}</h2>
//                         <p>{elel.description}</p>
//                         <p>Price: ${elel.price}</p>

//                         <div className="d-flex align-items-center gap-2">
//                             <button
//                                 className="btn btn-danger"
//                                 onClick={() => decrement(index)}
//                                 disabled={elel.quantity <= 1}
//                             >
//                                 −
//                             </button>

//                             <input
//                                 type="number"
//                                 className="form-control"
//                                 style={{ width: "80px" }}
//                                 value={elel.quantity}
//                                 readOnly
//                             />

//                             <button
//                                 className="btn btn-success"
//                                 onClick={() => increment(index)}
//                                 disabled={elel.quantity >= elel.stock}
//                             >
//                                 +
//                             </button>
//                         </div>

//                         <p className="mt-2">Stock: {elel.stock}</p>
//                     </div>
//                 </div>
//             ))}
//         </div>
//     )
// }

// export default Moredetail



import React, { useState } from 'react'

const Moredetail = () => {
    
    const [count, setCount] = useState(() => {
        return JSON.parse(localStorage.getItem("cart")) || []
    })

    function increment(index) {
        const updatedCart = [...count]
        console.log(updatedCart);
        const product = updatedCart[index]
        console.log(product);

        if (product.stock > 0) {
            product.quantity = (product.quantity || 1) + 1
            product.stock = product.stock - 1

            setCount(updatedCart)
            localStorage.setItem("cart", JSON.stringify(updatedCart))
        }
    }

    function decrement(index) {
        const updatedCart = [...count]
        const product = updatedCart[index]

        if (product.quantity > 1) {
            product.quantity -= 1
            product.stock += 1

            setCount(updatedCart)
            localStorage.setItem("cart", JSON.stringify(updatedCart))
        }
    }

    return (
        <div className="container mt-4">
            {count.map((elel, index) => (
                <div
                    className="row align-items-center mb-4"
                    key={elel.id || index}
                >
                    <div className="col-md-5">
                        <img
                            src={elel.thumbnail}
                            alt={elel.title}
                            className="img-fluid"
                        />
                    </div>

                    <div className="col-md-7">
                        <h2>{elel.title}</h2>
                        <p>{elel.description}</p>
                        {/* <p>Price: ${elel.price}</p> */}
                        {/* Price: ₹{(elel.price * 88).toFixed(2)} */}
                        <p>
                            Price: {new Intl.NumberFormat('en-IN', {
                                style: 'currency',
                                currency: 'INR'
                            }).format(elel.price * 1)}
                        </p>

                        <div className="d-flex align-items-center gap-2">
                            <button
                                className="btn btn-danger"
                                onClick={() => decrement(index)}
                                disabled={elel.quantity <= 1}
                            >
                                -
                            </button>

                            <input
                                type="number"
                                className="form-control"
                                style={{ width: "80px" }}
                                value={elel.quantity || 1}
                                readOnly
                            />

                            <button
                                className="btn btn-success"
                                onClick={() => increment(index)}
                                disabled={elel.stock <= 0}
                            >
                                +
                            </button>
                        </div>

                        <p className="mt-2">
                            Remaining Stock: {elel.stock}
                        </p>
                    </div>
                </div>
            ))}
        </div>
    )
}

export default Moredetail
