import './App.css'
import Home from './components/Home'
import Header from './common/Header'
import Footer from './common/Footer'
import About from './components/About'
import Service from './components/Service'
import Login from './Auth/Login'
import Register from './Auth/Register'
import Demo from './components/Demo'
import { createBrowserRouter, Outlet, RouterProvider } from 'react-router-dom'

const Layout = () => {
  return (
    <>
      <Header />
      <Outlet />
      <Footer />
    </>
  )
}

function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: <Layout />,
      children: [
        {
          index: true,
          element: <Home />
        },
        {
          path: 'home/about/detail',
          element: <Home />
        },
        {
          path: 'about/:id/:as',
          element: <About />
        },
        {
          path: 'service',
          element: <Service />
        },
        {
          path: 'login',
          element: <Login />
        },
        {
          path: 'register',
          element: <Register />
        }
      ]
    }
    ,
    {
      path: "/demo",
      element: <Demo />
    }
  ])

  return <RouterProvider router={router} />
}

export default App