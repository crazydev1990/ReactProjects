import { useParams } from 'react-router-dom'

function About() {
  const { id, as } = useParams()
  useSearchParams()
  console.log(id);

  return (
    <>
      <h1>About Page</h1>
      <h2>ID: {id} and {as}</h2>
    </>
  )
}

export default About