import React from 'react'

const Demo = () => {
    return (
        <h1 className="text-9xl font-bold underline bg-[#ff0000]">
            Hello world!
        </h1>
    )
}

export default Demo