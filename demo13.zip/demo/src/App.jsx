import './App.css'
import { useState } from 'react';

function App() {
  // let fullName = "John doe"
  // let count = 0
  // console.log(useState(0));
  let [value,setValue] = useState(0)

  console.log("func");

  function increment() {
    console.log("abc");
    // count = count + 1
    b(a + 1)
    // console.log(count);
  }

  return (
    <>
      {
        console.log("ui")
      }
      <h1>Welcome to React {a}</h1>
      <button onClick={increment}>click me</button>
    </>
  )
}

export default App
