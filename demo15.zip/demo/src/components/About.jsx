const About = () => {
    return (
        <>
            <h2>About</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A fugit accusantium voluptatibus veniam dolores reiciendis laboriosam ducimus molestias vel, sit temporibus minus nisi quia aperiam molestiae quod? Nemo, mollitia odit.</p>
        </>
    )
}
export default About