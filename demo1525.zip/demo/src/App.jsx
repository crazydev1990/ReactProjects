
import './App.css'
import ListCard from './components/ListCard'
import Navbar from './common/Navbar'

function App() {

  return (
    <>
      <Navbar />
      <ListCard />

    </>
  )
}

export default App
