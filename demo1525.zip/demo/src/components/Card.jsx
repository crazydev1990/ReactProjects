import React from 'react'
import indexDb from "../scrip"
const Card = (props) => {
    // console.log(props);
    const { data } = props
    const { thumbnail, title, price } = data
    console.log(data);
    return (
        <>
            <div class="bg-neutral-primary-soft block max-w-sm border border-default rounded-base shadow-xs">
                <a href="#">
                    <img class="rounded-t-base" src={thumbnail} alt="" />
                </a>
                <div class="p-6 text-center">
                    <span class="inline-flex items-center bg-brand-softer border border-brand-subtle text-fg-brand-strong text-xs font-medium px-1.5 py-0.5 rounded-sm">

                        Trending
                    </span>
                    <a href="#">
                        <h5 class="mt-3 mb-6 text-2xl font-semibold tracking-tight text-heading">{title}</h5>
                    </a>
                    <p>{data.description}</p>

                    <h4><span>₹ </span>{price}</h4>
                    <button className='border my-4 flex items-center px-3 py-2 rounded-2xl bg-amber-400 text-1xl font-semibold'>
                        Add to Cart
                        <svg class="w-4 h-4 ms-1.5 rtl:rotate-180 -me-0.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 12H5m14 0-4 4m4-4-4-4" /></svg>
                    </button>
                </div>
            </div>

        </>
    )
}

export default Card