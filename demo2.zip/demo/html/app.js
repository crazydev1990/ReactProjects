let x=10
// console.log('x value is'+x);
// console.log(`x value is ${x}`);

function f1(x,) {
    console.log(x);
    
}
f1(x,20)