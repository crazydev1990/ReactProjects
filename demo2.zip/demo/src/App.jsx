
import './App.css'
import Home from './components/Home'
import About from './components/About'
import Contact from './components/Contact'
import Service from './components/Service'
import Blog from './components/Blog'
function App() {
  let x = 10
  return (
    <>
      {/* <Contact /> */}
      <Blog />
      {/* <Service y={x} name='jkas' phone='83214' /> */}
      {/* <Home />
      
      <About /> */}
    </>
  )
}

export default App
