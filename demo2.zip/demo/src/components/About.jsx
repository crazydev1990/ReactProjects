
const About = () => {
    let style = {
        backgroundColor: "yellow",
        fontSize: "20px",
        color: "red"
    }



    return (
        <>
            <h1 style={{ backgroundColor: "blue", color: 'white' }}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore, dolores.</h1>
            <h2>About</h2>
            <p style={style}>Lorem ipsum dolor sit amet consectetur adipisicing elit. A fugit accusantium voluptatibus veniam dolores reiciendis laboriosam ducimus molestias vel, sit temporibus minus nisi quia aperiam molestiae quod? Nemo, mollitia odit.</p>
        </>
    )
}
export default About