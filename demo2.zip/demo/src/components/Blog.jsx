import React from 'react'
import { useEffect } from 'react'

const Blog = () => {


    useEffect(() => {
        console.log("function first");
    }, [])



    return (
        <>
            <h1>Blog</h1>
            {console.log("ui second")}
        </>
    )
}

export default Blog