import React from 'react'
// DKASD 
const Contact = () => {
    // let name = "coreXtrime"
    // let x = 10
    // let arr = [10, 20, 30, 40]
    // let user = {
    //     name: 'coreXtrime',
    //     phone: 93432,
    //     address: "Ratnaaker "
    // }
    return (
        <h1>Contact {user.address}</h1>
    )
}

export default Contact