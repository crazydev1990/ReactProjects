import image from '../assets/hero.png'
import style from '../components/Home.module.css'
// console.log(style);
const Home = () => {

    return (
        <>
            <h1 className={style.h1}>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Incidunt, repudiandae?</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dignissimos magni veniam eum itaque debitis non ducimus pariatur, ratione esse, rerum, amet error cum quas. Ea aut praesentium aperiam officia dicta.</p>
            {/* <img src="./favicon.svg" alt="" /> */}
            {/* <img src={image} alt="" /> */}

        </>
    )
}
export default Home