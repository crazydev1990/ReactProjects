import React from 'react'

const Service = (props) => {
    console.log(props);
    let name = "RJD"
    // let x=10
    return (
        <h1>Service is given by Goverment of {props.y}</h1>
    )
}

export default Service