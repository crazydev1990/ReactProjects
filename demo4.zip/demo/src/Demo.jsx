import React from 'react'
import { useState, useEffect } from 'react';
const Demo = () => {

    const [value, setValue] = useState(0)

    console.log("function");

    function incremnt() {
        setValue(value + 1)
    }

    useEffect(() => {

        console.log("api");


    },[])




    return (
        <>
            {console.log("ui")}
            <h1>Welcome to Hooks {value}</h1>
            <button onClick={incremnt}>click me</button>
        </>
    )
}

export default Demo