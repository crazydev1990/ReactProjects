import './App.css'
import Demo from "./Demo"
import Home from "./Home"

function App() {



  return (
    <>
      {/* <Demo /> */}
      <Home />
    </>
  )
}

export default App
