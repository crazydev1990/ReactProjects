import React from 'react'
import { useState, useEffect } from 'react';
const Demo = () => {

    let [value, setValue] = useState(0)

    console.log("function");

    function incremnt() {
        value = value + 1
        setValue(value)
        console.log(value);
    }
    console.log(value);
    
    useEffect(() => {

        console.log("api");


    }, [])




    return (
        <>
            {console.log("ui")}
            <h1>Welcome to Hooks {value}</h1>
            <button onClick={incremnt}>click me</button>
        </>
    )
}

export default Demo