import React from 'react'
import { useState, useEffect } from 'react'
import SingleUser from './SingleUser'
const Home = () => {

    const [value, setValue] = useState(0)
    const [user, setUsers] = useState([])
    const [singleone, setSingle] = useState({})

    function incre() {
        setValue(value + 1)
    }
    const users = async () => {
        const res = await fetch("https://reqres.in/api/users")
        const data = await res.json()
        setUsers(data.data)
        console.log(data.data);

    }
    useEffect(() => {
        users()
    }, [])

    function single(id) {
        console.log(id);
        setSingle(id)
    }

    console.log(user);
    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col">
                        {/* <h1>This is a home page {value}</h1> */}
                        {/* <button onClick={incre}>click me</button> */}
                        {user.map((userobject, index) => {
                            return (

                                <div key={userobject.id} onClick={() => single(userobject.id)}>
                                    <img src={userobject.avatar} alt="" />
                                    <h2> {userobject.first_name + userobject.last_name}</h2>
                                </div>




                            )
                        })}


                    </div>
                    <div className="col">
                        <SingleUser id={singleone} />
                    </div>
                </div>
            </div>

        </>
    )
}

export default Home

// https://reqres.in/api/users/4