import React from 'react'
import { useEffect, useState } from 'react';
const SingleUser = (props) => {

    const [s, setS] = useState({})

    console.log(props);
    const { id } = props
    console.log(id);

    const single = async () => {
        const res = await fetch(`https://reqres.in/api/users/${id}`)
        const data = await res.json()
        console.log(data?.data);
        setS(data?.data)
    }


    useEffect(() => {
        single()
    }, [id])


    return (
        <div>
            <img src={s?.avatar} alt="" />
        </div>
    )
}

export default SingleUser