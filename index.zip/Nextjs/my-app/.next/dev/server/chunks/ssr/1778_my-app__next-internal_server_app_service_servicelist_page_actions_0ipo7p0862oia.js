module.exports = [
"[project]/ml/Nextjs/my-app/.next-internal/server/app/service/servicelist/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=1778_my-app__next-internal_server_app_service_servicelist_page_actions_0ipo7p0862oia.js.map