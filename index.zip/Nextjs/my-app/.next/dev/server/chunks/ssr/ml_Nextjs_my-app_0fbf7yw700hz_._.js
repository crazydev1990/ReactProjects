(()=>{"use strict";module.exports = [
"[project]/ml/Nextjs/my-app/app/about/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>About
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$ml$2f$Nextjs$2f$my$2d$app$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/ml/Nextjs/my-app/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
'use client';
;
async function About() {
    const data = await fetch('https://jsonplaceholder.typicode.com/users');
    const posts = await data.json();
    console.log(posts);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$ml$2f$Nextjs$2f$my$2d$app$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
        children: posts.map((post)=>// <li key={post.id}>{post.title}</li>
            console.log(post.name))
    }, void 0, false, {
        fileName: "[project]/ml/Nextjs/my-app/app/about/page.jsx",
        lineNumber: 7,
        columnNumber: 9
    }, this);
}
}),
"[project]/ml/Nextjs/my-app/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/ml/Nextjs/my-app/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime;
}),
];})()

//# sourceMappingURL=ml_Nextjs_my-app_0fbf7yw700hz_._.js.map