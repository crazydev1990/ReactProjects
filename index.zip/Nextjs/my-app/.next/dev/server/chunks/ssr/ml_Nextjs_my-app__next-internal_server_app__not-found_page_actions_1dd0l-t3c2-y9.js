module.exports = [
"[project]/ml/Nextjs/my-app/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ml_Nextjs_my-app__next-internal_server_app__not-found_page_actions_1dd0l-t3c2-y9.js.map