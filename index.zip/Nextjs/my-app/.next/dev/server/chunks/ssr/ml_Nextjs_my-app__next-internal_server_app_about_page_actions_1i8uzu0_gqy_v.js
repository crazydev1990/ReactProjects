module.exports = [
"[project]/ml/Nextjs/my-app/.next-internal/server/app/about/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ml_Nextjs_my-app__next-internal_server_app_about_page_actions_1i8uzu0_gqy_v.js.map