module.exports = [
"[project]/ml/Nextjs/my-app/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ml_Nextjs_my-app__next-internal_server_app_page_actions_0lc_to8bt3yuq.js.map