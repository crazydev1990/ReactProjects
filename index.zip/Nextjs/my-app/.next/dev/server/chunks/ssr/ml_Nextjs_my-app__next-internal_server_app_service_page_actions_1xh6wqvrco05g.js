module.exports = [
"[project]/ml/Nextjs/my-app/.next-internal/server/app/service/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ml_Nextjs_my-app__next-internal_server_app_service_page_actions_1xh6wqvrco05g.js.map