globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/1lk6_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0nhi41d8f-nh5._.js",
    "static/chunks/1lk6_next_dist_compiled_next-devtools_index_1c_s8edatg87y.js",
    "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom-client_development_0vdxx7t_scvav.js",
    "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom_development_15l86ogva2ug1.js",
    "static/chunks/1lk6_next_dist_compiled_react-dom_0opsseabtueux._.js",
    "static/chunks/1lk6_next_dist_compiled_react-server-dom-turbopack_1k_e8cdhek-35._.js",
    "static/chunks/1lk6_next_dist_compiled_0hs0dlwj4bv5c._.js",
    "static/chunks/1lk6_next_dist_client_0flzp1glbxjmx._.js",
    "static/chunks/1lk6_next_dist_0dmdjj6utgkzt._.js",
    "static/chunks/1lk6_@swc_helpers_cjs_1x79v5fz9mmsz._.js",
    "static/chunks/ml_Nextjs_my-app_1anvha4rlo79g._.js",
    "static/chunks/turbopack-ml_Nextjs_my-app_1jm2xxbcam78q._.js"
  ],
  "rootMainFilesTree": {
    "/service/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0nhi41d8f-nh5._.js",
      "static/chunks/1lk6_next_dist_compiled_next-devtools_index_1c_s8edatg87y.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom-client_development_0vdxx7t_scvav.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom_development_15l86ogva2ug1.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_0opsseabtueux._.js",
      "static/chunks/1lk6_next_dist_compiled_react-server-dom-turbopack_1k_e8cdhek-35._.js",
      "static/chunks/1lk6_next_dist_compiled_0hs0dlwj4bv5c._.js",
      "static/chunks/1lk6_next_dist_client_0flzp1glbxjmx._.js",
      "static/chunks/1lk6_next_dist_0dmdjj6utgkzt._.js",
      "static/chunks/1lk6_@swc_helpers_cjs_1x79v5fz9mmsz._.js",
      "static/chunks/ml_Nextjs_my-app_1anvha4rlo79g._.js",
      "static/chunks/turbopack-ml_Nextjs_my-app_1jm2xxbcam78q._.js",
      "static/chunks/ml_Nextjs_my-app_0ppbwk4q6va-9._.js"
    ],
    "/about/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0nhi41d8f-nh5._.js",
      "static/chunks/1lk6_next_dist_compiled_next-devtools_index_1c_s8edatg87y.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom-client_development_0vdxx7t_scvav.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom_development_15l86ogva2ug1.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_0opsseabtueux._.js",
      "static/chunks/1lk6_next_dist_compiled_react-server-dom-turbopack_1k_e8cdhek-35._.js",
      "static/chunks/1lk6_next_dist_compiled_0hs0dlwj4bv5c._.js",
      "static/chunks/1lk6_next_dist_client_0flzp1glbxjmx._.js",
      "static/chunks/1lk6_next_dist_0dmdjj6utgkzt._.js",
      "static/chunks/1lk6_@swc_helpers_cjs_1x79v5fz9mmsz._.js",
      "static/chunks/ml_Nextjs_my-app_1anvha4rlo79g._.js",
      "static/chunks/turbopack-ml_Nextjs_my-app_1jm2xxbcam78q._.js",
      "static/chunks/ml_Nextjs_my-app_1ihvo1x5l23wo._.js"
    ],
    "/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0nhi41d8f-nh5._.js",
      "static/chunks/1lk6_next_dist_compiled_next-devtools_index_1c_s8edatg87y.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom-client_development_0vdxx7t_scvav.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom_development_15l86ogva2ug1.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_0opsseabtueux._.js",
      "static/chunks/1lk6_next_dist_compiled_react-server-dom-turbopack_1k_e8cdhek-35._.js",
      "static/chunks/1lk6_next_dist_compiled_0hs0dlwj4bv5c._.js",
      "static/chunks/1lk6_next_dist_client_0flzp1glbxjmx._.js",
      "static/chunks/1lk6_next_dist_0dmdjj6utgkzt._.js",
      "static/chunks/1lk6_@swc_helpers_cjs_1x79v5fz9mmsz._.js",
      "static/chunks/ml_Nextjs_my-app_1anvha4rlo79g._.js",
      "static/chunks/turbopack-ml_Nextjs_my-app_1jm2xxbcam78q._.js",
      "static/chunks/ml_Nextjs_my-app_219uq1sj0q91c._.js"
    ],
    "/_not-found/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0nhi41d8f-nh5._.js",
      "static/chunks/1lk6_next_dist_compiled_next-devtools_index_1c_s8edatg87y.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom-client_development_0vdxx7t_scvav.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_cjs_react-dom_development_15l86ogva2ug1.js",
      "static/chunks/1lk6_next_dist_compiled_react-dom_0opsseabtueux._.js",
      "static/chunks/1lk6_next_dist_compiled_react-server-dom-turbopack_1k_e8cdhek-35._.js",
      "static/chunks/1lk6_next_dist_compiled_0hs0dlwj4bv5c._.js",
      "static/chunks/1lk6_next_dist_client_0flzp1glbxjmx._.js",
      "static/chunks/1lk6_next_dist_0dmdjj6utgkzt._.js",
      "static/chunks/1lk6_@swc_helpers_cjs_1x79v5fz9mmsz._.js",
      "static/chunks/ml_Nextjs_my-app_1anvha4rlo79g._.js",
      "static/chunks/turbopack-ml_Nextjs_my-app_1jm2xxbcam78q._.js",
      "static/chunks/ml_Nextjs_my-app_18x7jxupx5rou._.js"
    ]
  },
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
