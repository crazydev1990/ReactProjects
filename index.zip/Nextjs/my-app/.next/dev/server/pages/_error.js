var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/1lk6_0-ikqygrsh51y._.js")
R.c("server/chunks/ssr/[externals]__10y2j2aka8e1v._.js")
R.c("server/chunks/ssr/1lk6_1wfsx8__idkk8._.js")
R.c("server/chunks/ssr/[externals]__1vp7etusa_gny._.js")
R.c("server/chunks/ssr/1lk6_next_0m_0zheszjhys._.js")
R.m("[project]/ml/Nextjs/my-app/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/ml/Nextjs/my-app/node_modules/next/dist/pages/_error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/ml/Nextjs/my-app/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/ml/Nextjs/my-app/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/ml/Nextjs/my-app/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/ml/Nextjs/my-app/node_modules/next/dist/pages/_error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/ml/Nextjs/my-app/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/ml/Nextjs/my-app/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
