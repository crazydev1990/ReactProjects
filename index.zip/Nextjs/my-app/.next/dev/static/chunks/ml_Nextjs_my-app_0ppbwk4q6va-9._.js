(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__10qvyanxe9f_n._.css","static/chunks/1lk6_next_dist_0sh_ixhxnuirf._.js"],
    source: "entry"
});
