(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/1lk6_next_dist_compiled_0c2ud-5kt715w._.js","static/chunks/1lk6_next_dist_shared_lib_19o3sos8pzo81._.js","static/chunks/1lk6_next_dist_client_0wb17dx9yj5g8._.js","static/chunks/1lk6_next_dist_13-od59sue9c-._.js","static/chunks/[next]_entry_page-loader_ts_0sua1f7owln0t._.js","static/chunks/1lk6_react-dom_cjs_react-dom-client_development_1_io2r0sukh3v.js","static/chunks/1lk6_react-dom_cjs_react-dom_development_1iq8pcpc8uj01.js","static/chunks/1lk6_react-dom_0sxau_e5br9vz._.js","static/chunks/1lk6_1657run-1rvmo._.js","static/chunks/[root-of-the-server]__0qp-xqx2tjhy7._.js"],
    source: "entry"
});
