__turbopack_load_page_chunks__("/_app", [
  "static/chunks/1lk6_next_dist_compiled_0o-i45-6vp23p._.js",
  "static/chunks/1lk6_next_dist_shared_lib_0bwjk30ptc46t._.js",
  "static/chunks/1lk6_next_dist_client_01isrknzcqwm3._.js",
  "static/chunks/1lk6_next_dist_1lku3csr8_uk4._.js",
  "static/chunks/1lk6_next_app_0hgm05jb0e8v8.js",
  "static/chunks/[next]_entry_page-loader_ts_0_zkef7ixu0w2._.js",
  "static/chunks/1lk6_react-dom_cjs_react-dom-client_development_1_io2r0sukh3v.js",
  "static/chunks/1lk6_react-dom_cjs_react-dom_development_1iq8pcpc8uj01.js",
  "static/chunks/1lk6_react-dom_0sxau_e5br9vz._.js",
  "static/chunks/1lk6_1tbsor4wtq3pi._.js",
  "static/chunks/[root-of-the-server]__0aqm7iw4y2hv2._.js",
  "static/chunks/ml_Nextjs_my-app_pages__app_0du2_q-cjzmdk._.js",
  "static/chunks/turbopack-ml_Nextjs_my-app_pages__app_1ch2vhb7u27ii._.js"
])
