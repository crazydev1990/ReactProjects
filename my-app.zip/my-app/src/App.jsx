import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'
import Home from './components/Home'
import About from './components/About'
import Contact from './components/Contact'
import Service from './components/Service'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* fragments to accept multi values to return */}
      <h1>Hello</h1>
      <p>Welcome to React Js.</p>
      
      {/* सही किया हुआ कंपोनेंट (Capital H के साथ) */}
      <Home /> 
      <About />
      <Service />
      <Contact />
    </>
  )
}

export default App
