const Home=()=>{
    return(
        <div>
            <h1>Home1</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quod.</p>
        </div>
    )
}
export default Home;