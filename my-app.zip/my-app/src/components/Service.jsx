const Service=()=>{
     return(
        <div>
            <h1>Service</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quod.</p>
        </div>
    )
}
export default Service;