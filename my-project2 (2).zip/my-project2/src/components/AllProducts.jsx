import React from 'react'
import {useState,useEffect} from 'react'
import Card from './Card'


const AllProducts = () => {
    const [prodData,setProdData]=useState([]);
    const products=async()=>{    
    const res=await fetch('https://fakestoreapi.com/products')
    const data=await res.json()
    console.log(data)
    setProdData(data)
}
useEffect(()=>{
    products()
},[])
  return (
    <>
      <div className="flex flex-wrap justify-center gap-2">
        {prodData.map((item)=>{
           return <Card key={item.id} data={item} />
        })}
      </div>
    </>
  )
}

export default AllProducts
