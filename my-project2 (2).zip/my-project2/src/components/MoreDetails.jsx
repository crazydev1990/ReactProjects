import React from 'react'
import { useState } from 'react'

const MoreDetails = () => {
    const [count, setCount] = useState(() => {
        return JSON.parse(localStorage.getItem('cart')) || [];
    });
    
    function handleIncrement(index)
    {
        const updatedCart=[...count];
        console.log(updatedCart);
        const prod=updatedCart[index];
        prod.quantity++;
        setCount(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
    }
    
    function handleDecrement(index){
        const updatedCart=[...count];
        const prod=updatedCart[index];
        if(prod.quantity>1){
            prod.quantity--;
            setCount(updatedCart);
            localStorage.setItem('cart', JSON.stringify(updatedCart));
        }
    }
    
    return (
        <div className="container py-5" style={{ backgroundColor: '#f1f3f6', minHeight: '100vh', fontFamily: 'Arial, sans-serif' }}>
            <h1 className="my-4 text-center font-weight-bold text-dark border-bottom pb-3" style={{ letterSpacing: '1px' }}>
                Shopping Cart Details 🛒
            </h1>
            
            {count && count.map((item, index) => {
                return (
                    <div className="row align-items-center mb-4 bg-white p-4 rounded shadow-sm border mx-1" key={item.id || index} style={{ transition: 'all 0.3s ease' }}>                
                        
                        {/* ડાબી બાજુ: પ્રોડક્ટ ઈમેજ (Amazon/Flipkart ની જેમ પરફેક્ટ ફિટ) */}
                        <div className="col-md-4 text-center mb-3 mb-md-0">
                            <div style={{ width: '100%', height: '220px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f9f9f9', padding: '15px', borderRadius: '8px', border: '1px solid #f0f0f0' }}>
                                <img 
                                    src={item.image} 
                                    alt={item.title} 
                                    className='thumbnail img-fluid' 
                                    style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }} 
                                />
                            </div>
                        </div>
                        
                        <div className="col-md-8">
                            <h3 className="font-weight-bold text-dark mb-2 h4 text-truncate-2" style={{ lineHeight: '1.4' }}>{item.title}</h3>
                            <p className="text-muted small text-justify mb-3" style={{ color: '#666', fontSize: '13px' }}>{item.description}</p>
                            <p className="font-weight-bold h5 mb-3" style={{ color: '#212121' }}>
                                Price: <span className="text-dark">{new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(item.price)}</span>
                            </p>
                            <div className="flex items-center gap-3 mb-3 d-flex align-items-center">
                                <button 
                                    className="btn btn-sm btn-danger px-3 py-1 font-weight-bold text-white shadow-sm" 
                                    style={{ borderRadius: '4px', backgroundColor: '#e53935', border: 'none', minWidth: '35px' }}
                                    onClick={() => handleDecrement(index)}
                                >
                                    -
                                </button>
                                <input 
                                    type="number" 
                                    className="form-control text-center font-weight-bold border mx-2" 
                                    style={{ width: '50px', height: '32px', display: 'inline-block', backgroundColor: '#f8f9fa' }} 
                                    value={item.quantity} 
                                    readOnly 
                                />
                                <button 
                                    className="btn btn-sm btn-success px-3 py-1 font-weight-bold text-white shadow-sm" 
                                    style={{ borderRadius: '4px', backgroundColor: '#43a047', border: 'none', minWidth: '35px' }}
                                    onClick={() => handleIncrement(index)}
                                >
                                    +
                                </button>
                            </div>
                            <div className="pt-3 border-top d-flex flex-wrap align-items-center justify-content-between gap-3">
                                <p className="text-success font-weight-bold h5 mb-0">
                                    Total: {new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(item.price * (item.quantity || 1))}
                                </p>
                                <span className="text-muted small bg-light px-3 py-1 rounded border text-uppercase" style={{ fontSize: '11px', fontWeight: '600' }}>
                                    {item.category}
                                </span>
                                <p className="text-warning font-weight-bold mb-0" style={{ fontSize: '15px' }}>
                                    ★ <span className="text-dark font-weight-bold">{item.rating?.rate || "No rating"}</span>
                                </p>
                            </div>

                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default MoreDetails;
