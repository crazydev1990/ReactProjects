import React from 'react'
import ReactDom from 'react-dom'
import './App.css'
import AllProducts from './components/AllProducts'
import Navbar from './common/Navbar'
import Footer from './common/Footer'
function App() {  

  return (
    <>
      <Navbar />
      <AllProducts />
      <Footer />
    
    </>
  )
}

export default App
