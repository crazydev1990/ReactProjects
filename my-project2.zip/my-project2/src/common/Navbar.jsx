import React from 'react'

const Navbar = () => {
  return (
    <nav className="bg-[#fde047] px-6 py-4 shadow-md">
      {/* મુખ્ય કન્ટેનર: justify-between થી લોગો ડાબે અને મેનૂ જમણે જશે */}
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* ૧. ડાબી બાજુનો લોગો (Flipkart જેવો) */}
        <div className="flex items-center">
          <img 
            src="https://static.vecteezy.com/system/resources/previews/054/650/802/non_2x/flipkart-logo-rounded-flipkart-logo-free-download-flipkart-logo-free-png.png" 
            alt="Logo" 
            className="h-18 object-contain"
          />
        </div>

        {/* ૨. જમણી બાજુનું મેનૂ: flex અને gap-6 થી બધું પ્રોપર એક લાઇનમાં ગોઠવાશે */}
        <div className="flex items-center gap-6 text-lg font-medium text-gray-800">
          <a href="#" className="hover:text-blue-600 transition-colors">Home</a>
          <a href="#" className="hover:text-blue-600 transition-colors">About</a>
          <a href="#" className="hover:text-blue-600 transition-colors">Contact</a>
          <a href="#" className="hover:text-blue-600 transition-colors">Services</a>
          <a href="#" className="hover:text-blue-600 transition-colors">Blog</a>
          {/* ગેલેરીને એક્ટિવ લુક આપવા માટે બેકગ્રાઉન્ડ બ્લુ રાખ્યું છે */}
          <a href="#" className="bg-amber-700 text-white px-4 py-2 rounded-lg shadow-sm hover:bg-blue-700 transition-all">Gallery</a>
          
          {/* શોપિંગ કાર્ટ આઇકોન માટે જગ્યા */}
          <div className="relative cursor-pointer ms-2">
            <span className="text-2xl">🛒</span>
            <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full">0</span>
          </div>
        </div>
      </div>
    </nav>
  )
}
export default Navbar
