import React from 'react'

const Card = (props) => {
  // ✅ props માંથી ડેટા કાઢવા માટે props.data લખવું પડે અને name ની જગ્યાએ title
  const { title, image, description, price, rating, category } = props.data

  return (
    <>
      <div className="bg-neutral-primary-soft block max-w-sm p-6 border border-default rounded-base">
        <a href="#">
          <img className="rounded-base h-40 mx-auto object-contain" src={image} alt="no image" />
        </a>
        
        <a href="#">
          <h5 className="mt-6 mb-2 text-2xl font-semibold tracking-tight text-heading">{title}</h5>
        </a>
        
        <p className="mb-6 text-body">{description}</p>
        <p className="mb-6 text-body">Price: ${price}</p>
        <p className="mb-6 text-body">Rating: {rating?.rate} ⭐ ({rating?.count} reviews)</p>
        <p className="mb-6 text-body">Category: {category}</p>
       
        <div className="w-full flex justify-center mt-4">
         <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all font-medium">
            Add to cart
         </button>
        </div>
      </div>
    </>
  )
}

export default Card
