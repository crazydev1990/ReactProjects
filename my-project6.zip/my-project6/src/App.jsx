import './App.css'
import SalesChart from '../src/components/chart'
import ProductChart from '../src/components/ProductChart'
function App() {

  return (
    <>
    <SalesChart/>
    <ProductChart/>
    </>
  )
}

export default App
