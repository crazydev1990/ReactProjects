import './App.css'
import Home from './components/Home'
import Header from './common/Header'
import Footer from './common/Footer'
import About from './components/About'
import Service from './components/Service'
import Login from './Auth/Login'
import Register from './Auth/Register'
import { createBrowserRouter, Outlet, RouterProvider } from 'react-router-dom'

const Layout = () => {
  return (
    <>
      <Header />
      <Outlet />
      <Footer />
    </>
  )
}

function App() {

  const router = createBrowserRouter([

    {
      path: '/',
      element: <Layout />,
      children: [
        {
          path: "/home",
          element: <Home />
        },
        {
          path: "/about",
          element: <About />
        },
        {
          path: "/service",
          element: <Service />
        }
        , {
          path: "/login",
          element: <Login />
        }
        , {
          path: "/register",
          element: <Register />
        }
      ]
    }



  ])

  return (
    <>
      <RouterProvider router={router} />
      {/* <h1 className='bg-danger text-white'>Welcome to My Website</h1> */}
      {/* <Home />
      <About />
      <Service /> */}
    </>
  )
}

export default App
