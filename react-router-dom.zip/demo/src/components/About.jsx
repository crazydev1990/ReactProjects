import React from 'react'
import Header from '../common/Header'
const About = () => {
  return (
    <>
      {/* <Header /> */}
      <div>About</div>

    </>
  )
}

export default About