import React from 'react'
import Header from '../common/Header'
const Home = () => {
  return (
    <>
      {/* <Header /> */}
      <div>Home</div>
    </>
  )
}

export default Home